package com.example.quiz

object Constants {
    fun getQuestion(): ArrayList<Question>{
        val questionList = ArrayList<Question>()

        val ques1 = Question(1,
            "Which of the following has worst time complexity?",
            "Heap Sort",
            "MergeSort",
            "Radix Sort",
            "Insertion Sort",
            4)
        questionList.add(ques1)

        val ques2 = Question(2,
            "Does Merge Sort uses auxiliary space?",
            "Yes",
            "No",
            "Maybe",
            "None of the above",
            1)
        questionList.add(ques2)

        return questionList
    }
}